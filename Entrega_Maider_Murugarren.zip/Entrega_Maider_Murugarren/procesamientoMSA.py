#!/usr/bin/env python
# coding: utf-8

# In[3]:


import os
from Bio import SeqIO
import shutil

class Procesado:
    # Función para crear estructura de las carpteas completas
    def crear_directorios(carpeta_procX):
        # Carpeta base para cada procesado
        carpeta_proc = os.path.join(os.getcwd(), carpeta_procX)
        os.makedirs(carpeta_proc, exist_ok=True)
        # Archivo log vacio
        archivo_log = os.path.join(carpeta_proc, f"{carpeta_procX}_archivo.log")
        open(archivo_log, "w").close()
        # Archivo .data vacio
        archivo_configuracion = os.path.join(carpeta_proc, f"{carpeta_procX}_archivo.data")
        open(archivo_configuracion, "w").close()
        # Carpeta origen dentro de cada procesado
        carpeta_orig_fuente = os.path.join(carpeta_proc, f"{carpeta_procX}_orig")
        os.makedirs(carpeta_orig_fuente, exist_ok=True)
        # Carpeta proc dentro de cada procesado
        carpeta_proc = os.path.join(carpeta_proc, "proc")
        os.makedirs(carpeta_proc, exist_ok=True)
        # Carpetas con los distintos alineamientos dentro de cada procesado
        tipos_alineamientos = ["CLUSTAL", "MUSCLE", "TCOFF" ]
        for tipo in tipos_alineamientos:

            sub_alineamiento = os.path.join(carpeta_proc, tipo)
            os.makedirs(sub_alineamiento, exist_ok=True)

            sub_sub_Output = os.path.join(sub_alineamiento, "Output")
            os.makedirs(sub_sub_Output, exist_ok=True)

            sub_sub_clustal = os.path.join(sub_alineamiento, "Clustal")
            os.makedirs(sub_sub_clustal, exist_ok=True)

            sub_sub_pyhilip = os.path.join(sub_alineamiento, "Phylip")
            os.makedirs(sub_sub_pyhilip, exist_ok=True)

            sub_sub_pyhilip_relax = os.path.join(sub_alineamiento, "Phylio_relaxed")
            os.makedirs(sub_sub_pyhilip_relax, exist_ok=True)

            sub_sub_fasta = os.path.join(sub_alineamiento, "Fasta")
            os.makedirs(sub_sub_fasta, exist_ok=True)
    
    # Función para hacer 3 subconjuntos de datos para cada procesado
    def calsificador(ruta_origen):
        # Recorremos todos los archivos en la ruta y los leemos
        for archivo in os.listdir(ruta):
            ruta_completa = os.path.join(ruta, archivo)
            seq_record = SeqIO.read(ruta_completa, "fasta")
            
            # Obtenemos al lingutud de cada uno
            longitud = len(seq_record.seq)
            
            # Los reubicamso segun su longitud a diferentes procesos
            if (longitud > 1000):
                ruta_destino1 = "proc1/proc1_orig/"
                shutil.copy(ruta_completa, ruta_destino1) 
            elif (longitud > 450):
                ruta_destino2 = "proc2/proc2_orig/"
                shutil.copy(ruta_completa, ruta_destino2)
            else:
                ruta_destino3 = "proc3/proc3_orig/"
                shutil.copy(ruta_completa, ruta_destino3)
    
    # Función para rellenar tanto el archivo.data como el archivo.log
    def introducir_datos(ruta_data, ruta_log, nombre_procesado):
    
        ruta_orig = nombre_procesado + "/"+ nombre_procesado + "_orig"
        lista_archivos = []
        for archivo in os.listdir(ruta_orig):
            lista_archivos.append(archivo)

        #Empezamos rellenando los datos en el proc_archivo.data
        with open(ruta_data, "w") as archivo_data:
            archivo_data.write(f'''Nombre: procesamiento_{nombre_procesado}. 
            \nArchivos: {lista_archivos}. \n
            \nTools: 'CLUSTAL', 'MUSCLE', 'TCOFFE'. 
            \nTipo secuencia: dna. 
            \nEmail: 'mmi1006@alu.ubu.es' 
            \nOutputFolder: Output ''')

        # Rellenamos también el contenido del proc_archivo.log
        with open(ruta_log, 'w') as archivo_log:
            archivo_log.write("Procesado de secuencias en Python y alinemiento de las mismas. \nFecha comienzo: 21/05/2023 \nFecha final: 29/05/2023 \n Tipo de evento: Preprocesamiento de los datos, procesamiento de las secuencias alineandolas con diferentes métodos de MSA.")
    
    # Función para extrer los parametro que contiene en cada caso el archivo.data
    def extraer_parametros(ruta_data):
        with open(ruta_data, "r") as archivo_data:
            contenido = archivo_data.read()
        # Extraemos los parametros qeu contiene el arcivo uno a uno 
        procesado_name = contenido.split("Nombre: ")[1].split(".")[0].strip()
        procesado_archivos = contenido.split("Archivos: [")[1].split("]")[0].split(", ")
        procesado_email = contenido.split("Email: '")[1].split("'")[0].strip()
        procesado_tipo = contenido.split("Tipo secuencia: ")[1].split(".")[0].strip()
        procesado_tools = contenido.split("Tools: '")[1].split("'")[0].split("', '")
        procesado_outputfolder = contenido.split("OutputFolder: ")[1].strip(".")

        return procesado_name, procesado_archivos, procesado_email, procesado_tipo, procesado_tools, procesado_outputfolder

    # Función que une los las secuencias de todos  lso fasta es uno único
    def Union_fastas(ruta_orig):
        # Recorremos los archivos qeu hay en la ruta dada
        archivos = [archivo for archivo in os.listdir(ruta_orig) if archivo.endswith(".fasta")]
        
        # Creamos dos listas vacias donde se almacenarán las secuencias de cada caso
        secuencias_nucleotidos = []
        secuencias_aminoacidos = []
        
        # Volvemos a recorrer los archivos leyendo su contenido
        for archivo in archivos:
            ruta_archivo = os.path.join(ruta_orig, archivo)
            secuencias = SeqIO.parse(ruta_archivo, "fasta")
            
            # Identificamos si se trata de un archivo con nucleotidos o aminoacidos
            if "nucleotido" in archivo:
                secuencias_nucleotidos.extend(secuencias)
            elif "aminoacido" in archivo:
                secuencias_aminoacidos.extend(secuencias)
        #En el caso de que no se repita la secuencia la escribimos en el nuevo fasta
        nom_archivo_nucleotido = os.path.join(ruta_orig, "secuencias_nucleotidos.fasta")
        if secuencias_nucleotidos:
            with open(nom_archivo_nucleotido, "w") as archivo_nuc:
                SeqIO.write(secuencias_nucleotidos, archivo_nuc, "fasta")

        nom_archivo_aminoacido =  os.path.join(ruta_orig, "secuencias_aminoacidos.fasta")
        if secuencias_aminoacidos:
            with open(nom_archivo_aminoacido, "w") as archivo_aa:
                SeqIO.write(secuencias_aminoacidos, archivo_aa, "fasta") 
    
    # Función para alinear, de forma manual cada tipo con todos lso datos
    def alinear():
    
        # Alineamos con cada tipo de alieamiento y con cada fasta correspondiente 
        # Alinemiento CLUSTEL
        get_ipython().run_line_magic('run', '-i modulos/clustalo.py --email mmi1006@alu.ubu.es --stype dna --sequence proc1/proc1_orig/secuencias_nucleotidos.fasta --outfmt clustal --outfile proc1/proc/CLUSTAL/Output/clustal')
        get_ipython().run_line_magic('run', '-i modulos/clustalo.py --email mmi1006@alu.ubu.es --stype dna --sequence proc2/proc2_orig/secuencias_nucleotidos.fasta --outfmt clustal --outfile proc2/proc/CLUSTAL/Output/clustal')
        get_ipython().run_line_magic('run', '-i modulos/clustalo.py --email mmi1006@alu.ubu.es --stype protein --sequence proc2/proc2_orig/secuencias_aminoacidos.fasta --outfmt clustal --outfile proc2/proc/CLUSTAL/Output/clustal')
        get_ipython().run_line_magic('run', '-i modulos/clustalo.py --email mmi1006@alu.ubu.es --stype protein --sequence proc3/proc3_orig/secuencias_aminoacidos.fasta --outfmt clustal --outfile proc3/proc/CLUSTAL/Output/clustal')


        # Alinemiento MUSCLE
        get_ipython().run_line_magic('run', '-i modulos/muscle.py --email mmi1006@alu.ubu.es --sequence proc1/proc1_orig/secuencias_nucleotidos.fasta --outfile proc1/proc/MUSCLE/Output/muscle')
        get_ipython().run_line_magic('run', '-i modulos/muscle.py --email mmi1006@alu.ubu.es --sequence proc2/proc2_orig/secuencias_nucleotidos.fasta --outfile proc2/proc/MUSCLE/Output/muscle')
        get_ipython().run_line_magic('run', '-i modulos/muscle.py --email mmi1006@alu.ubu.es --sequence proc2/proc2_orig/secuencias_aminoacidos.fasta --outfile proc2/proc/MUSCLE/Output/muscle')
        get_ipython().run_line_magic('run', '-i modulos/muscle.py --email mmi1006@alu.ubu.es --sequence proc3/proc3_orig/secuencias_aminoacidos.fasta --outfile proc3/proc/MUSCLE/Output/muscle')

        # Alinemiento TCOFEE
        get_ipython().run_line_magic('run', '-i modulos/tcoffee.py --email mmi1006@alu.ubu.es --stype dna --sequence proc1/proc1_orig/secuencias_nucleotidos.fasta --outfile proc1/proc/TCOFF/Output/tcoffee')
        get_ipython().run_line_magic('run', '-i modulos/tcoffee.py --email mmi1006@alu.ubu.es --stype dna --sequence proc2/proc2_orig/secuencias_nucleotidos.fasta --outfile proc2/proc/TCOFF/Output/tcoffee')
        get_ipython().run_line_magic('run', '-i modulos/tcoffee.py --email mmi1006@alu.ubu.es --stype protein --sequence proc2/proc2_orig/secuencias_aminoacidos.fasta --outfile proc2/proc/TCOFF/Output/tcoffee')
        get_ipython().run_line_magic('run', '-i modulos/tcoffee.py --email mmi1006@alu.ubu.es --stype protein --sequence proc3/proc3_orig/secuencias_aminoacidos.fasta --outfile proc3/proc/TCOFF/Output/tcoffee')

    # Función para reubicar lo obtenido en el alinemiento a la carpeta correspondiente
    def reubicar(carpeta_origen):
        return None

