#!/usr/bin/env python
# coding: utf-8

# In[3]:


import os
from Bio import SeqIO
import shutil

class preprocesamiento():
    
    #Función para crear la carpeta para lso fasta
    def crear_dic(self, ruta, nombre_dic):
        # El condicional no devolvera la carpeta o un mensaje si ya esta creada.
        try:
            os.mkdir(nombre_dic)
            print("Se ha creado la carpeta.")
        except FileExistsError: 
            print("La carpeta ya esta creada.")
    
    # La función para obtener los fasta desde lso genbank
    def convertir_fasta(self, ruta):
        # Recorremos todos los archivo que hay en la carptea y los leemso
        for archivo in os.listdir(ruta):
            ruta_completa = os.path.join(ruta, archivo)
            seq_record = SeqIO.read(ruta_completa, "genbank")
            
            # Creamos los nombres que tendrán en cada caso los fasta
            archivo_nucleotidos = "Orig/" + seq_record.id + "_nucleotido.fasta"
            archivo_aminoacidos = "Orig/" + seq_record.id + "_aminoacido.fasta"
            
            # Crear una lista con el objeto seq_record
            seq_records = [seq_record]
            # Escribimos el nucleoritdo dentro de un fasta
            SeqIO.write(seq_record, archivo_nucleotidos, "fasta")

            # Sacamos la secuencia de aminoacidos también
            sec_aminoacido = seq_record.translate()
            # Recuperamos también el id  y la descripción de la secuencia inicial
            sec_aminoacido.id = seq_record.id
            sec_aminoacido.description = seq_record.description
            
            sec_aminoacido = [sec_aminoacido]
            # Escribimos la secuencia de aminoacido en un fasta también
            SeqIO.write(sec_aminoacido, archivo_aminoacidos, "fasta")

